import { DeviceFrame } from "@/components/device-frame"
import { AppShell } from "@/components/trading/app-shell"

export default function HomePage() {
  return (
    <DeviceFrame>
      <AppShell />
    </DeviceFrame>
  )
}
