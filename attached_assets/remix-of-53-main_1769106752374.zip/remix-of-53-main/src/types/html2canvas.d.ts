declare module 'html2canvas' {
  const html2canvas: any;
  export default html2canvas;
}
