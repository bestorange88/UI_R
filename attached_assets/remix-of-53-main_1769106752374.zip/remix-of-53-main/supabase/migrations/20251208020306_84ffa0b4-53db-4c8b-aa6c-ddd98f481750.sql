-- Create admin_users table for independent admin authentication
CREATE TABLE public.admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  email text,
  is_active boolean DEFAULT true,
  last_login_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Only service role can access admin_users (no client-side access)
CREATE POLICY "No client access to admin_users" 
ON public.admin_users 
FOR ALL 
USING (false);

-- Create function to verify admin password
CREATE OR REPLACE FUNCTION public.verify_admin_password(
  _username text,
  _password text
)
RETURNS TABLE(admin_id uuid, admin_username text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT au.id, au.username
  FROM public.admin_users au
  WHERE au.username = _username
    AND au.password_hash = crypt(_password, au.password_hash)
    AND au.is_active = true;
  
  -- Update last login time if successful
  IF FOUND THEN
    UPDATE public.admin_users 
    SET last_login_at = now(), updated_at = now()
    WHERE username = _username;
  END IF;
END;
$$;

-- Enable pgcrypto extension for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Insert initial admin user (username: admin, password: Aa112211)
INSERT INTO public.admin_users (username, password_hash, email)
VALUES ('admin', crypt('Aa112211', gen_salt('bf')), 'admin@arx.com');