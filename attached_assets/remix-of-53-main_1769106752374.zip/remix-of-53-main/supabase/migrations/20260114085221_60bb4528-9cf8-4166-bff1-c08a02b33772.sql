-- 创建一个函数来正确加密密码
CREATE OR REPLACE FUNCTION public.hash_password(_password text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public', 'pg_temp'
AS $$
BEGIN
  RETURN extensions.crypt(_password, extensions.gen_salt('bf'));
END;
$$;

-- 修复现有的明文密码（检查是否是明文）
UPDATE cs_agents 
SET password_hash = extensions.crypt(password_hash, extensions.gen_salt('bf'))
WHERE password_hash NOT LIKE '$2a$%' AND password_hash NOT LIKE '$2b$%';

-- 添加消息已读状态字段（如果不存在）
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'cs_messages' AND column_name = 'read_at'
  ) THEN
    ALTER TABLE cs_messages ADD COLUMN read_at timestamp with time zone DEFAULT NULL;
  END IF;
END $$;

-- 创建更新消息为已读的函数
CREATE OR REPLACE FUNCTION public.mark_messages_as_read(
  _conversation_id uuid,
  _reader_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public', 'pg_temp'
AS $$
BEGIN
  -- 标记对方发送的消息为已读
  -- 如果读者是用户，则标记客服/AI发送的消息
  -- 如果读者是客服，则标记用户发送的消息
  UPDATE cs_messages
  SET read_at = now(), is_read = true
  WHERE conversation_id = _conversation_id
    AND read_at IS NULL
    AND (
      (_reader_type = 'user' AND sender_type IN ('agent', 'ai', 'system'))
      OR (_reader_type = 'agent' AND sender_type = 'user')
    );
END;
$$;