-- Add wallet_address column to profiles table for account linking
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS wallet_address text;

-- Add password_set flag to track if user has set a password (for wallet-only users)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS has_password boolean DEFAULT false;

-- Create index for wallet address lookup
CREATE INDEX IF NOT EXISTS idx_profiles_wallet_address ON public.profiles(wallet_address) WHERE wallet_address IS NOT NULL;