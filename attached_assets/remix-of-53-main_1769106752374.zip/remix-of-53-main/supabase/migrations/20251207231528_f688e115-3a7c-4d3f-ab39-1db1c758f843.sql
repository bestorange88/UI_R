-- Add unique constraint on source_url for upsert to work
ALTER TABLE crypto_news ADD CONSTRAINT crypto_news_source_url_key UNIQUE (source_url);