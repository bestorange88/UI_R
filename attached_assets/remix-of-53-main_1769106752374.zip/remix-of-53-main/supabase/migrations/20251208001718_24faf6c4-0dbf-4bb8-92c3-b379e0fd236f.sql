-- Create expert strategies table for quant trading
CREATE TABLE public.expert_strategies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  strategy_type TEXT NOT NULL DEFAULT 'grid',
  symbol TEXT NOT NULL DEFAULT 'BTC-USDT',
  expert_name TEXT NOT NULL,
  expert_avatar TEXT,
  profit_rate NUMERIC NOT NULL DEFAULT 0,
  win_rate NUMERIC NOT NULL DEFAULT 0,
  total_profit NUMERIC NOT NULL DEFAULT 0,
  total_trades INTEGER NOT NULL DEFAULT 0,
  followers_count INTEGER NOT NULL DEFAULT 0,
  min_investment NUMERIC NOT NULL DEFAULT 100,
  risk_level TEXT NOT NULL DEFAULT 'medium',
  is_active BOOLEAN DEFAULT true,
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.expert_strategies ENABLE ROW LEVEL SECURITY;

-- Anyone can view active expert strategies
CREATE POLICY "Anyone can view active expert strategies"
  ON public.expert_strategies
  FOR SELECT
  USING (is_active = true);

-- Admins can manage expert strategies
CREATE POLICY "Admins can manage expert strategies"
  ON public.expert_strategies
  FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Create expert strategy subscriptions table
CREATE TABLE public.expert_strategy_subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  strategy_id UUID NOT NULL REFERENCES public.expert_strategies(id) ON DELETE CASCADE,
  investment_amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  profit NUMERIC DEFAULT 0,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ended_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.expert_strategy_subscriptions ENABLE ROW LEVEL SECURITY;

-- Users can view own subscriptions
CREATE POLICY "Users can view own subscriptions"
  ON public.expert_strategy_subscriptions
  FOR SELECT
  USING (user_id = auth.uid());

-- Users can create own subscriptions
CREATE POLICY "Users can create own subscriptions"
  ON public.expert_strategy_subscriptions
  FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- Admins can view all subscriptions
CREATE POLICY "Admins can view all subscriptions"
  ON public.expert_strategy_subscriptions
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Admins can update subscriptions
CREATE POLICY "Admins can update subscriptions"
  ON public.expert_strategy_subscriptions
  FOR UPDATE
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Insert sample expert strategies
INSERT INTO public.expert_strategies (name, description, strategy_type, symbol, expert_name, profit_rate, win_rate, total_profit, total_trades, followers_count, min_investment, risk_level, config) VALUES
('穩健網格王', '經典網格策略，適合震盪行情，風險可控收益穩定', 'grid', 'BTC-USDT', '量化大師', 12.5, 78.5, 125800, 1520, 328, 500, 'low', '{"gridSize": 10, "priceRange": 5}'),
('趨勢追蹤者', '均線交叉策略，捕捉中長期趨勢，適合趨勢行情', 'sma-cross', 'ETH-USDT', '幣圈老王', 28.3, 65.2, 283500, 856, 215, 1000, 'medium', '{"fast": 20, "slow": 50}'),
('閃電套利', '跨交易所套利策略，低風險高頻交易', 'arbitrage', 'BTC-USDT', '套利專家', 8.2, 92.1, 82000, 5680, 156, 5000, 'low', '{"minSpread": 0.1}'),
('波段獵手', 'RSI+MACD組合策略，精準捕捉波段', 'custom', 'SOL-USDT', '技術流小李', 35.6, 58.9, 356000, 423, 189, 200, 'high', '{"rsiPeriod": 14, "macdFast": 12}'),
('定投智能', 'AI優化定投策略，自動調整買入時機', 'dca', 'BTC-USDT', '穩健派阿明', 15.8, 85.3, 158000, 365, 512, 100, 'low', '{"interval": "daily", "amount": 100}');