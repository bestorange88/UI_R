-- Create storage bucket for customer service images
INSERT INTO storage.buckets (id, name, public)
VALUES ('cs-images', 'cs-images', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload images
CREATE POLICY "Authenticated users can upload cs images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'cs-images');

-- Allow anyone to view cs images (they are public)
CREATE POLICY "Anyone can view cs images"
ON storage.objects FOR SELECT
USING (bucket_id = 'cs-images');

-- Allow users to delete their own images
CREATE POLICY "Users can delete own cs images"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'cs-images' AND auth.uid()::text = (storage.foldername(name))[1]);