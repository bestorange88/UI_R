-- Enable pgcrypto extension for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Update the admin password with proper hash (since it might have been stored incorrectly)
UPDATE public.admin_users 
SET password_hash = crypt('Aa112211', gen_salt('bf'))
WHERE username = 'admin';