-- Stock Trading Tables

-- Table for available stock symbols
CREATE TABLE public.stock_symbols (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  market TEXT NOT NULL DEFAULT 'US',
  sector TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for stock orders
CREATE TABLE public.stock_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  symbol TEXT NOT NULL,
  order_type TEXT NOT NULL, -- 'market', 'limit', 'stop', 'stop_limit'
  side TEXT NOT NULL, -- 'buy', 'sell'
  quantity NUMERIC NOT NULL,
  price NUMERIC,
  stop_price NUMERIC,
  filled_quantity NUMERIC DEFAULT 0,
  avg_fill_price NUMERIC,
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'partial', 'filled', 'cancelled', 'rejected'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for stock positions
CREATE TABLE public.stock_positions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  symbol TEXT NOT NULL,
  quantity NUMERIC NOT NULL DEFAULT 0,
  avg_cost NUMERIC NOT NULL DEFAULT 0,
  market_value NUMERIC DEFAULT 0,
  unrealized_pnl NUMERIC DEFAULT 0,
  realized_pnl NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, symbol)
);

-- Futures Trading Tables

-- Table for available futures contracts
CREATE TABLE public.futures_contracts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  symbol TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  underlying TEXT NOT NULL,
  contract_size NUMERIC NOT NULL DEFAULT 1,
  tick_size NUMERIC NOT NULL DEFAULT 0.01,
  expiry_date DATE,
  is_perpetual BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  max_leverage INTEGER DEFAULT 100,
  maintenance_margin NUMERIC DEFAULT 0.5,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for futures orders
CREATE TABLE public.futures_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  symbol TEXT NOT NULL,
  order_type TEXT NOT NULL, -- 'market', 'limit', 'stop', 'stop_limit'
  side TEXT NOT NULL, -- 'buy', 'sell'
  position_side TEXT NOT NULL DEFAULT 'both', -- 'long', 'short', 'both'
  quantity NUMERIC NOT NULL,
  price NUMERIC,
  stop_price NUMERIC,
  leverage INTEGER NOT NULL DEFAULT 1,
  filled_quantity NUMERIC DEFAULT 0,
  avg_fill_price NUMERIC,
  status TEXT NOT NULL DEFAULT 'pending',
  reduce_only BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for futures positions
CREATE TABLE public.futures_positions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  symbol TEXT NOT NULL,
  side TEXT NOT NULL, -- 'long', 'short'
  quantity NUMERIC NOT NULL DEFAULT 0,
  entry_price NUMERIC NOT NULL DEFAULT 0,
  mark_price NUMERIC DEFAULT 0,
  liquidation_price NUMERIC,
  margin NUMERIC NOT NULL DEFAULT 0,
  leverage INTEGER NOT NULL DEFAULT 1,
  unrealized_pnl NUMERIC DEFAULT 0,
  realized_pnl NUMERIC DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open', -- 'open', 'closed', 'liquidated'
  closed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.stock_symbols ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.futures_contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.futures_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.futures_positions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for stock_symbols
CREATE POLICY "Anyone can view active stock symbols" ON public.stock_symbols
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage stock symbols" ON public.stock_symbols
  FOR ALL USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for stock_orders
CREATE POLICY "Users can view own stock orders" ON public.stock_orders
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create own stock orders" ON public.stock_orders
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all stock orders" ON public.stock_orders
  FOR SELECT USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update stock orders" ON public.stock_orders
  FOR UPDATE USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for stock_positions
CREATE POLICY "Users can view own stock positions" ON public.stock_positions
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Service can manage stock positions" ON public.stock_positions
  FOR ALL USING (true);

-- RLS Policies for futures_contracts
CREATE POLICY "Anyone can view active futures contracts" ON public.futures_contracts
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage futures contracts" ON public.futures_contracts
  FOR ALL USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for futures_orders
CREATE POLICY "Users can view own futures orders" ON public.futures_orders
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create own futures orders" ON public.futures_orders
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all futures orders" ON public.futures_orders
  FOR SELECT USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update futures orders" ON public.futures_orders
  FOR UPDATE USING (has_role(auth.uid(), 'admin'));

-- RLS Policies for futures_positions
CREATE POLICY "Users can view own futures positions" ON public.futures_positions
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create own futures positions" ON public.futures_positions
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all futures positions" ON public.futures_positions
  FOR SELECT USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update futures positions" ON public.futures_positions
  FOR UPDATE USING (has_role(auth.uid(), 'admin'));

-- Create updated_at triggers
CREATE TRIGGER update_stock_symbols_updated_at
  BEFORE UPDATE ON public.stock_symbols
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_stock_orders_updated_at
  BEFORE UPDATE ON public.stock_orders
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_stock_positions_updated_at
  BEFORE UPDATE ON public.stock_positions
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_futures_contracts_updated_at
  BEFORE UPDATE ON public.futures_contracts
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_futures_orders_updated_at
  BEFORE UPDATE ON public.futures_orders
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_futures_positions_updated_at
  BEFORE UPDATE ON public.futures_positions
  FOR EACH ROW EXECUTE FUNCTION public.handle_updated_at();