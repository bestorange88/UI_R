-- Insert seed data for expert_showcases
INSERT INTO public.expert_showcases (title, expert_name, symbol, direction, leverage, profit_amount, profit_percent, entry_price, exit_price, description, is_active) VALUES 
('BTC突破行情精準抄底', '幣圈老王', 'BTC-USDT', 'long', 50, 12580, 125.8, 88500, 92300, '趨勢突破確認後入場，設好止損止盈', true),
('ETH回調做多策略', '量化小張', 'ETH-USDT', 'long', 25, 5680, 56.8, 3150, 3420, '技術面回調支撐位做多', true),
('SOL高位做空獲利', '短線王者', 'SOL-USDT', 'short', 20, 3250, 32.5, 185, 168, '超買區間做空，完美出場', true),
('BTC震盪套利', '穩健派阿明', 'BTC-USDT', 'long', 10, 8900, 89.0, 89200, 91500, '區間震盪策略，低風險高收益', true),
('ETH趨勢跟蹤', '技術流小李', 'ETH-USDT', 'long', 30, 6720, 67.2, 3080, 3350, '均線金叉確認多頭趨勢', true);