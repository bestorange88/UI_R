-- Add category column to time_contract_assets table
ALTER TABLE public.time_contract_assets 
ADD COLUMN category text NOT NULL DEFAULT 'crypto';

-- Update existing assets with correct categories
UPDATE public.time_contract_assets 
SET category = 'crypto' 
WHERE coin_symbol LIKE '%-USDT';

UPDATE public.time_contract_assets 
SET category = 'futures' 
WHERE coin_symbol IN ('ES', 'NQ', 'CL', 'GC', 'SI', 'NG', 'ZB', 'ZN');

UPDATE public.time_contract_assets 
SET category = 'stock' 
WHERE coin_symbol IN ('AAPL', 'GOOGL', 'MSFT', 'TSLA', 'AMZN', 'NVDA', 'META');

-- Create index for better performance on category filtering
CREATE INDEX idx_time_contract_assets_category ON public.time_contract_assets(category);