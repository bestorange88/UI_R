-- 創建大神曬單表
CREATE TABLE public.expert_showcases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  profit_amount NUMERIC NOT NULL DEFAULT 0,
  profit_percent NUMERIC NOT NULL DEFAULT 0,
  symbol TEXT NOT NULL DEFAULT 'BTC-USDT',
  direction TEXT NOT NULL DEFAULT 'long',
  leverage INTEGER NOT NULL DEFAULT 10,
  entry_price NUMERIC,
  exit_price NUMERIC,
  image_url TEXT,
  expert_name TEXT NOT NULL,
  expert_avatar TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 創建用戶跟單記錄表
CREATE TABLE public.follow_trades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  showcase_id UUID NOT NULL REFERENCES public.expert_showcases(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  leverage INTEGER NOT NULL DEFAULT 10,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 啟用 RLS
ALTER TABLE public.expert_showcases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follow_trades ENABLE ROW LEVEL SECURITY;

-- 大神曬單 RLS 策略
CREATE POLICY "Anyone can view active showcases" 
ON public.expert_showcases 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage showcases" 
ON public.expert_showcases 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role));

-- 跟單記錄 RLS 策略
CREATE POLICY "Users can create follow trades" 
ON public.follow_trades 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can view own follow trades" 
ON public.follow_trades 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Admins can view all follow trades" 
ON public.follow_trades 
FOR SELECT 
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update follow trades" 
ON public.follow_trades 
FOR UPDATE 
USING (has_role(auth.uid(), 'admin'::app_role));