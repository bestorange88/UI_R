-- Fix admin password verification to use pgcrypto installed in schema `extensions`
CREATE OR REPLACE FUNCTION public.verify_admin_password(_username text, _password text)
RETURNS TABLE(admin_id uuid, admin_username text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO public, pg_temp
AS $$
BEGIN
  RETURN QUERY
  SELECT au.id, au.username
  FROM public.admin_users au
  WHERE au.username = _username
    AND au.password_hash = extensions.crypt(_password, au.password_hash)
    AND au.is_active = true;
  
  -- Update last login time if successful
  IF FOUND THEN
    UPDATE public.admin_users 
    SET last_login_at = now(), updated_at = now()
    WHERE username = _username;
  END IF;
END;
$$;

-- Ensure the built-in admin password is stored as a pgcrypto hash
UPDATE public.admin_users 
SET password_hash = extensions.crypt('Aa112211', extensions.gen_salt('bf'))
WHERE username = 'admin';
