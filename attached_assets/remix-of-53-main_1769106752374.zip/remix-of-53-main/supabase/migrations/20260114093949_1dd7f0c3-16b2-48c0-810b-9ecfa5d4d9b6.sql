-- Fix feedback INSERT policy to prevent user impersonation
DROP POLICY IF EXISTS "Users can insert feedback" ON public.user_feedback;

CREATE POLICY "Users can insert own feedback"
ON public.user_feedback
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);