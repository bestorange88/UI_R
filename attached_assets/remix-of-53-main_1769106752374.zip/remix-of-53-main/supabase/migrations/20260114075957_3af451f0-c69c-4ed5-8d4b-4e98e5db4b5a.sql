-- 客服坐席表
CREATE TABLE public.cs_agents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  avatar_url TEXT,
  is_online BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  max_conversations INTEGER DEFAULT 10,
  current_conversations INTEGER DEFAULT 0,
  last_login_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 快捷回复模板表
CREATE TABLE public.cs_quick_replies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES public.cs_agents(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 会话表
CREATE TABLE public.cs_conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  agent_id UUID REFERENCES public.cs_agents(id),
  status TEXT NOT NULL DEFAULT 'waiting', -- waiting, active, transferred, closed
  is_ai_mode BOOLEAN DEFAULT false,
  priority INTEGER DEFAULT 0,
  last_message_at TIMESTAMP WITH TIME ZONE,
  last_message_preview TEXT,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ended_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 消息表
CREATE TABLE public.cs_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.cs_conversations(id) ON DELETE CASCADE,
  sender_type TEXT NOT NULL, -- user, agent, ai, system
  sender_id UUID, -- user_id or agent_id
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'text', -- text, image, system
  image_url TEXT,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 会话转接记录表
CREATE TABLE public.cs_transfers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.cs_conversations(id) ON DELETE CASCADE,
  from_agent_id UUID REFERENCES public.cs_agents(id),
  to_agent_id UUID REFERENCES public.cs_agents(id),
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 启用 RLS
ALTER TABLE public.cs_agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cs_quick_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cs_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cs_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cs_transfers ENABLE ROW LEVEL SECURITY;

-- RLS 策略 - 通过 Edge Functions 使用 service role 访问
-- 客服坐席表 - 仅服务端访问
CREATE POLICY "Service role can manage cs_agents"
ON public.cs_agents FOR ALL
USING (auth.role() = 'service_role');

-- 快捷回复 - 仅服务端访问
CREATE POLICY "Service role can manage cs_quick_replies"
ON public.cs_quick_replies FOR ALL
USING (auth.role() = 'service_role');

-- 会话表 - 用户可以查看自己的会话
CREATE POLICY "Users can view own conversations"
ON public.cs_conversations FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Service role can manage cs_conversations"
ON public.cs_conversations FOR ALL
USING (auth.role() = 'service_role');

-- 消息表 - 用户可以查看自己会话的消息
CREATE POLICY "Users can view messages in own conversations"
ON public.cs_messages FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.cs_conversations
    WHERE id = cs_messages.conversation_id
    AND user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert messages in own conversations"
ON public.cs_messages FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.cs_conversations
    WHERE id = cs_messages.conversation_id
    AND user_id = auth.uid()
  )
);

CREATE POLICY "Service role can manage cs_messages"
ON public.cs_messages FOR ALL
USING (auth.role() = 'service_role');

-- 转接记录 - 仅服务端访问
CREATE POLICY "Service role can manage cs_transfers"
ON public.cs_transfers FOR ALL
USING (auth.role() = 'service_role');

-- 创建索引优化查询
CREATE INDEX idx_cs_conversations_user_id ON public.cs_conversations(user_id);
CREATE INDEX idx_cs_conversations_agent_id ON public.cs_conversations(agent_id);
CREATE INDEX idx_cs_conversations_status ON public.cs_conversations(status);
CREATE INDEX idx_cs_messages_conversation_id ON public.cs_messages(conversation_id);
CREATE INDEX idx_cs_messages_created_at ON public.cs_messages(created_at);

-- 启用实时功能
ALTER PUBLICATION supabase_realtime ADD TABLE public.cs_conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE public.cs_messages;

-- 更新时间戳触发器
CREATE TRIGGER update_cs_agents_updated_at
BEFORE UPDATE ON public.cs_agents
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_cs_quick_replies_updated_at
BEFORE UPDATE ON public.cs_quick_replies
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_cs_conversations_updated_at
BEFORE UPDATE ON public.cs_conversations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 验证客服密码的函数
CREATE OR REPLACE FUNCTION public.verify_agent_password(_username TEXT, _password TEXT)
RETURNS TABLE(agent_id UUID, agent_username TEXT, agent_display_name TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
BEGIN
  RETURN QUERY
  SELECT ca.id, ca.username, ca.display_name
  FROM public.cs_agents ca
  WHERE ca.username = _username
    AND ca.password_hash = extensions.crypt(_password, ca.password_hash)
    AND ca.is_active = true;
  
  IF FOUND THEN
    UPDATE public.cs_agents 
    SET last_login_at = now(), updated_at = now(), is_online = true
    WHERE username = _username;
  END IF;
END;
$$;