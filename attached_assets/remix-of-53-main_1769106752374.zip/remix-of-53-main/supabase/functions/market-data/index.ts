import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Fallback prices when API is unavailable
const fallbackPrices: Record<string, { last: string; open24h: string; high24h: string; low24h: string; vol24h: string; volCcy24h: string }> = {
  'BTC-USDT': { last: '89500', open24h: '89000', high24h: '91000', low24h: '87500', vol24h: '5000', volCcy24h: '445000000' },
  'ETH-USDT': { last: '3040', open24h: '3020', high24h: '3150', low24h: '2900', vol24h: '150000', volCcy24h: '456000000' },
  'SOL-USDT': { last: '131', open24h: '130', high24h: '136', low24h: '127', vol24h: '650000', volCcy24h: '85150000' },
  'XRP-USDT': { last: '2.03', open24h: '2.02', high24h: '2.11', low24h: '1.99', vol24h: '18000000', volCcy24h: '36540000' },
  'BNB-USDT': { last: '890', open24h: '885', high24h: '906', low24h: '870', vol24h: '13000', volCcy24h: '11570000' },
  'DOGE-USDT': { last: '0.138', open24h: '0.139', high24h: '0.143', low24h: '0.134', vol24h: '390000000', volCcy24h: '53820000' },
  'ADA-USDT': { last: '0.415', open24h: '0.413', high24h: '0.435', low24h: '0.405', vol24h: '30000000', volCcy24h: '12450000' },
  'AVAX-USDT': { last: '13.4', open24h: '13.3', high24h: '13.85', low24h: '12.95', vol24h: '700000', volCcy24h: '9380000' },
  'DOT-USDT': { last: '2.08', open24h: '2.13', high24h: '2.16', low24h: '2.04', vol24h: '1800000', volCcy24h: '3744000' },
  'POL-USDT': { last: '0.12', open24h: '0.122', high24h: '0.125', low24h: '0.118', vol24h: '6000000', volCcy24h: '720000' },
};

// In-memory cache for batch requests
const tickerCache: Map<string, { data: any; timestamp: number }> = new Map();
const CACHE_TTL = 5000; // 5 seconds cache

// Retry fetch with timeout
async function fetchWithRetry(url: string, retries = 2, timeout = 3000): Promise<Response> {
  for (let i = 0; i < retries; i++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      
      const response = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);
      
      if (response.ok) {
        return response;
      }
    } catch (err) {
      if (i === retries - 1) throw err;
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  throw new Error('All retries failed');
}

// Generate fallback ticker data
function getFallbackTickerData(symbol: string) {
  const fallback = fallbackPrices[symbol];
  if (!fallback) return null;
  
  return {
    instType: "SPOT",
    instId: symbol,
    last: fallback.last,
    lastSz: "0.001",
    askPx: fallback.last,
    askSz: "1",
    bidPx: fallback.last,
    bidSz: "1",
    open24h: fallback.open24h,
    high24h: fallback.high24h,
    low24h: fallback.low24h,
    volCcy24h: fallback.volCcy24h,
    vol24h: fallback.vol24h,
    ts: Date.now().toString(),
    sodUtc0: fallback.open24h,
    sodUtc8: fallback.open24h
  };
}

function getFallbackResponse(symbol: string) {
  const data = getFallbackTickerData(symbol);
  if (!data) return null;
  return { code: "0", msg: "", data: [data] };
}

// Fetch single ticker with caching
async function fetchSingleTicker(symbol: string): Promise<any> {
  const cached = tickerCache.get(symbol);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }
  
  try {
    const response = await fetchWithRetry(`https://www.okx.com/api/v5/market/ticker?instId=${symbol}`);
    const data = await response.json();
    
    if (data.code === "0" && data.data?.[0]) {
      tickerCache.set(symbol, { data: data.data[0], timestamp: Date.now() });
      return data.data[0];
    }
    
    const fallback = getFallbackTickerData(symbol);
    if (fallback) {
      tickerCache.set(symbol, { data: fallback, timestamp: Date.now() });
      return fallback;
    }
    return null;
  } catch {
    const fallback = getFallbackTickerData(symbol);
    if (fallback) {
      tickerCache.set(symbol, { data: fallback, timestamp: Date.now() });
      return fallback;
    }
    return null;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { action, exchange = 'okx', symbol, symbols, interval, limit, period, size } = body;

    if (!action) {
      return new Response(
        JSON.stringify({ error: 'Missing action parameter' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // OKX API handling
    if (exchange === 'okx') {
      // Single ticker
      if (action === 'ticker' && symbol) {
        const cached = tickerCache.get(symbol);
        if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
          return new Response(
            JSON.stringify({ code: "0", msg: "", data: [cached.data] }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        
        try {
          const response = await fetchWithRetry(`https://www.okx.com/api/v5/market/ticker?instId=${symbol}`);
          const data = await response.json();
          
          if (data.code === "0" && data.data?.[0]) {
            tickerCache.set(symbol, { data: data.data[0], timestamp: Date.now() });
          }
          
          return new Response(JSON.stringify(data), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        } catch {
          const fallback = getFallbackResponse(symbol);
          if (fallback) {
            return new Response(JSON.stringify(fallback), {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          throw new Error(`Failed to fetch ticker for ${symbol}`);
        }
      }
      
      // Batch tickers - optimized for fewer round trips
      if (action === 'batch_tickers' && symbols && Array.isArray(symbols)) {
        const tickers = await Promise.all(
          symbols.map(sym => fetchSingleTicker(sym))
        );
        
        return new Response(
          JSON.stringify({ tickers: tickers.filter(t => t !== null) }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      // Legacy tickers action
      if (action === 'tickers' && symbols) {
        const results = await Promise.all(
          symbols.map(async (sym: string) => {
            const ticker = await fetchSingleTicker(sym);
            if (ticker) {
              return { code: "0", msg: "", data: [ticker] };
            }
            return getFallbackResponse(sym);
          })
        );
        return new Response(JSON.stringify({ results }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      
      // Klines
      if (action === 'klines' && symbol) {
        const klineInterval = interval || '1H';
        const klineLimit = limit || 100;
        try {
          const response = await fetchWithRetry(
            `https://www.okx.com/api/v5/market/candles?instId=${symbol}&bar=${klineInterval}&limit=${klineLimit}`
          );
          const data = await response.json();
          return new Response(JSON.stringify(data), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        } catch {
          return new Response(
            JSON.stringify({ code: "0", msg: "", data: [] }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    }

    // HTX API handling
    if (exchange === 'htx') {
      if (action === 'ticker' && symbol) {
        try {
          const response = await fetchWithRetry(
            `https://api.huobi.pro/market/detail/merged?symbol=${symbol.toLowerCase().replace('-', '')}`
          );
          const data = await response.json();
          return new Response(JSON.stringify(data), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        } catch {
          return new Response(
            JSON.stringify({ status: 'error', err_msg: 'API unavailable' }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
      
      if (action === 'klines' && symbol) {
        const klinePeriod = period || '60min';
        const klineSize = size || 100;
        try {
          const response = await fetchWithRetry(
            `https://api.huobi.pro/market/history/kline?symbol=${symbol.toLowerCase().replace('-', '')}&period=${klinePeriod}&size=${klineSize}`
          );
          const data = await response.json();
          return new Response(JSON.stringify(data), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        } catch {
          return new Response(
            JSON.stringify({ status: 'ok', data: [] }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action or missing parameters' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown error';
    console.error('Error in market-data function:', errorMsg);
    return new Response(
      JSON.stringify({ error: 'Failed to fetch market data', details: errorMsg }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
