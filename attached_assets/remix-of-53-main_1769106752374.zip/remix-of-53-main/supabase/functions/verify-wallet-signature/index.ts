import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'
import { verifyMessage } from 'https://esm.sh/ethers@6.7.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { address, signature, nonce, expiresAt } = await req.json();

    if (!address || !signature || !nonce || !expiresAt) {
      return new Response(
        JSON.stringify({ error: 'Missing required parameters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Retrieve and validate nonce
    const { data: nonceData, error: nonceError } = await supabase
      .from('wallet_nonces')
      .select('*')
      .eq('address', address.toLowerCase())
      .eq('nonce', nonce)
      .eq('used', false)
      .single();

    if (nonceError || !nonceData) {
      return new Response(
        JSON.stringify({ error: 'Invalid or expired nonce' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if nonce is expired
    if (new Date(nonceData.expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ error: 'Nonce has expired' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify signature - use the exact expiresAt value from frontend to ensure match
    const message = `ARX Wallet Authentication\n\nNonce: ${nonce}\nAddress: ${address}\nExpires: ${expiresAt}`;
    
    let recoveredAddress: string;
    try {
      recoveredAddress = verifyMessage(message, signature);
    } catch (error) {
      console.error('Signature verification failed:', error);
      return new Response(
        JSON.stringify({ error: 'Invalid signature' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (recoveredAddress.toLowerCase() !== address.toLowerCase()) {
      return new Response(
        JSON.stringify({ error: 'Signature does not match address' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Mark nonce as used
    await supabase
      .from('wallet_nonces')
      .update({ used: true })
      .eq('id', nonceData.id);

    // Create or get user account
    const email = `${address.toLowerCase()}@wallet.arx.app`;
    
    let userId: string;
    
    // First, check if user already exists by email
    const { data: { users: existingUsers } } = await supabase.auth.admin.listUsers();
    const existingUser = existingUsers?.find(u => u.email === email);
    
    if (existingUser) {
      // User already exists, use their ID
      userId = existingUser.id;
      
      // Ensure wallet_address is set in profile
      await supabase.from('profiles').upsert({
        id: userId,
        email: email,
        username: `wallet_${address.slice(0, 8)}`,
        wallet_address: address.toLowerCase(),
      }, { onConflict: 'id' });
    } else {
      // Try to create new user
      const password = crypto.randomUUID() + crypto.randomUUID();
      const { data: newUser, error: signUpError } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { wallet_address: address.toLowerCase() }
      });

      if (signUpError || !newUser?.user) {
        console.error('Error creating wallet user:', signUpError);
        return new Response(
          JSON.stringify({ error: 'Failed to create user account' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      userId = newUser.user.id;

      // Create profile with wallet address for new users
      await supabase.from('profiles').upsert({
        id: userId,
        email: email,
        username: `wallet_${address.slice(0, 8)}`,
        wallet_address: address.toLowerCase(),
        has_password: false
      }, { onConflict: 'id' });

      // Create default role
      await supabase.from('user_roles').upsert({
        user_id: userId,
        role: 'trader'
      }, { onConflict: 'user_id,role' });
    }

    // Generate a proper session for the authenticated user
    const { data, error: signInError } = await supabase.auth.admin.generateLink({
      type: 'magiclink',
      email,
      options: {
        redirectTo: `${req.headers.get('origin') || 'http://localhost:8080'}/`
      }
    });

    if (signInError || !data?.properties?.hashed_token) {
      console.error('Failed to generate session:', signInError);
      return new Response(
        JSON.stringify({ error: 'Failed to generate session' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Exchange the hashed token for a real session - only token_hash and type should be provided
    const { data: sessionData, error: sessionError } = await supabase.auth.verifyOtp({
      type: 'magiclink',
      token_hash: data.properties.hashed_token
    });

    if (sessionError || !sessionData?.session) {
      console.error('Failed to create session:', sessionError);
      return new Response(
        JSON.stringify({ error: 'Failed to create session' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        session: sessionData.session,
        message: 'Wallet authenticated successfully'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in verify-wallet-signature:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});