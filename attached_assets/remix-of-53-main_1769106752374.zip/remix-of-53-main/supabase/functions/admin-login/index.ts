import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'
import { SignJWT, jwtVerify } from 'https://deno.land/x/jose@v4.14.4/index.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Secret key for admin JWT tokens - MUST be configured in environment
const adminJwtSecretValue = Deno.env.get('ADMIN_JWT_SECRET')
if (!adminJwtSecretValue) {
  console.error('CRITICAL: ADMIN_JWT_SECRET environment variable is not configured')
}
const ADMIN_JWT_SECRET = new TextEncoder().encode(adminJwtSecretValue || '')

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  // Check if ADMIN_JWT_SECRET is configured
  if (!adminJwtSecretValue) {
    console.error('Admin login failed: ADMIN_JWT_SECRET not configured')
    return new Response(
      JSON.stringify({ success: false, error: 'Server configuration error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    const { action, username, password, token } = await req.json()

    if (action === 'login') {
      // Verify admin credentials using database function
      const { data, error } = await supabase.rpc('verify_admin_password', {
        _username: username,
        _password: password
      })

      if (error) {
        console.error('Database error:', error)
        return new Response(
          JSON.stringify({ success: false, error: 'Authentication failed' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      if (!data || data.length === 0) {
        return new Response(
          JSON.stringify({ success: false, error: 'Invalid username or password' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      const admin = data[0]

      // Generate admin JWT token
      const adminToken = await new SignJWT({ 
        admin_id: admin.admin_id, 
        username: admin.admin_username,
        type: 'admin'
      })
        .setProtectedHeader({ alg: 'HS256' })
        .setIssuedAt()
        .setExpirationTime('24h')
        .sign(ADMIN_JWT_SECRET)

      console.log(`Admin login successful: ${admin.admin_username}`)

      return new Response(
        JSON.stringify({ 
          success: true, 
          token: adminToken,
          admin: {
            id: admin.admin_id,
            username: admin.admin_username
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (action === 'verify') {
      // Verify admin token
      if (!token) {
        return new Response(
          JSON.stringify({ valid: false, error: 'No token provided' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      try {
        const { payload } = await jwtVerify(token, ADMIN_JWT_SECRET)
        
        if (payload.type !== 'admin') {
          throw new Error('Invalid token type')
        }

        return new Response(
          JSON.stringify({ 
            valid: true, 
            admin: {
              id: payload.admin_id,
              username: payload.username
            }
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      } catch (verifyError) {
        console.error('Token verification failed:', verifyError)
        return new Response(
          JSON.stringify({ valid: false, error: 'Invalid or expired token' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
    }

    return new Response(
      JSON.stringify({ error: 'Invalid action' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error in admin-login:', error)
    return new Response(
      JSON.stringify({ success: false, error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
