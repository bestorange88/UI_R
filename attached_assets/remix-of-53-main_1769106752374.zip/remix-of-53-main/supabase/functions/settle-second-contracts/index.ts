import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting second contract settlement check...');

    // 首先获取全局控制设置
    const { data: globalConfig } = await supabase
      .from('system_configs')
      .select('config_value')
      .eq('config_key', 'second_contract_global_control')
      .single();

    const globalControlMode = globalConfig?.config_value?.mode || 'none';
    console.log(`Global control mode: ${globalControlMode}`);

    // 查询所有待结算且已到期的订单
    const now = new Date().toISOString();
    const { data: pendingOrders, error: queryError } = await supabase
      .from('second_contract_orders')
      .select('*')
      .eq('status', 'pending')
      .lte('settlement_time', now);

    if (queryError) {
      console.error('Error querying orders:', queryError);
      throw queryError;
    }

    console.log(`Found ${pendingOrders?.length || 0} orders to settle`);

    let settledCount = 0;
    let errorCount = 0;

    // 结算每个订单
    for (const order of pendingOrders || []) {
      try {
        let finalResult: 'win' | 'lose';
        let finalPrice = order.entry_price;
        let profit = 0;

        // 优先使用单个订单的设置,如果订单没有单独设置,才使用全局设置
        let effectiveControl = order.admin_result;
        
        // 如果订单没有单独设置(null或'real'),则使用全局设置
        if (!effectiveControl || effectiveControl === 'real') {
          effectiveControl = globalControlMode !== 'none' ? globalControlMode : 'real';
        }

        // 根据有效的控制设置或真实市场结果
        if (effectiveControl === 'win') {
          // 设为赢
          finalResult = 'win';
          profit = Number(order.amount) * order.yield_rate;
          finalPrice = order.direction === 'up' ? order.entry_price + 50 : order.entry_price - 50;
          console.log(`Order ${order.id} set to WIN by ${order.admin_result ? 'individual' : 'global'} control`);
        } else if (effectiveControl === 'lose') {
          // 设为输
          finalResult = 'lose';
          profit = -Number(order.amount);
          finalPrice = order.direction === 'up' ? order.entry_price - 50 : order.entry_price + 50;
          console.log(`Order ${order.id} set to LOSE by ${order.admin_result ? 'individual' : 'global'} control`);
        } else {
          // 真实结果:从多个价格源获取市场价格并使用中位数
          try {
            const prices = await Promise.allSettled([
              fetch(`https://www.okx.com/api/v5/market/ticker?instId=${order.symbol}`)
                .then(res => res.json())
                .then(data => data.code === '0' && data.data?.[0] ? parseFloat(data.data[0].last) : null),
              fetch(`https://api.huobi.pro/market/detail/merged?symbol=${order.symbol.toLowerCase().replace('-', '')}`)
                .then(res => res.json())
                .then(data => data.status === 'ok' && data.tick ? data.tick.close : null),
              fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${order.symbol.replace('-', '')}`)
                .then(res => res.json())
                .then(data => data.price ? parseFloat(data.price) : null)
            ]);

            const validPrices = prices
              .filter(p => p.status === 'fulfilled' && p.value !== null)
              .map(p => (p as PromiseFulfilledResult<number>).value);

            console.log(`Retrieved ${validPrices.length} valid prices for ${order.symbol}:`, validPrices);

            if (validPrices.length < 2) {
              // 价格源不足 - 跳过此订单,需要管理员处理
              console.error(`Insufficient price sources for order ${order.id}. Got ${validPrices.length}, need at least 2. Skipping settlement.`);
              
              await supabase.from('audit_logs').insert({
                user_id: order.user_id,
                action: 'contract_settlement_failed',
                resource_type: 'second_contract_order',
                resource_id: order.id,
                details: {
                  reason: 'insufficient_price_sources',
                  sources_available: validPrices.length,
                  symbol: order.symbol
                }
              });
              
              errorCount++;
              continue;
            }

            // 使用中位数防止异常值操纵
            validPrices.sort((a, b) => a - b);
            const medianIndex = Math.floor(validPrices.length / 2);
            finalPrice = validPrices.length % 2 === 0
              ? (validPrices[medianIndex - 1] + validPrices[medianIndex]) / 2
              : validPrices[medianIndex];

            // 验证价格偏差(超过10%需要人工审核)
            const priceDeviation = Math.abs(finalPrice - order.entry_price) / order.entry_price;
            if (priceDeviation > 0.1) {
              console.warn(`Large price deviation detected for order ${order.id}: ${(priceDeviation * 100).toFixed(2)}%`);
              
              await supabase.from('audit_logs').insert({
                user_id: order.user_id,
                action: 'contract_settlement_deviation_alert',
                resource_type: 'second_contract_order',
                resource_id: order.id,
                details: {
                  entry_price: order.entry_price,
                  settlement_price: finalPrice,
                  deviation_percent: priceDeviation * 100,
                  price_sources: validPrices
                }
              });
            }

            console.log(`Using median price ${finalPrice} from ${validPrices.length} sources for ${order.symbol}`);
          } catch (priceError) {
            console.error('Error fetching real price:', priceError);
            // 价格获取失败 - 跳过此订单
            console.error(`Failed to fetch prices for order ${order.id}. Skipping settlement.`);
            
            await supabase.from('audit_logs').insert({
              user_id: order.user_id,
              action: 'contract_settlement_failed',
              resource_type: 'second_contract_order',
              resource_id: order.id,
              details: {
                reason: 'price_fetch_error',
                error: priceError instanceof Error ? priceError.message : String(priceError),
                symbol: order.symbol
              }
            });
            
            errorCount++;
            continue;
          }

          const isWin = (order.direction === 'up' && finalPrice > order.entry_price) ||
                        (order.direction === 'down' && finalPrice < order.entry_price);
          finalResult = isWin ? 'win' : 'lose';
          profit = isWin ? Number(order.amount) * order.yield_rate : -Number(order.amount);
          console.log(`Order ${order.id} settled by REAL market price: ${finalPrice}`);
        }

        // 更新订单状态
        const { error: updateOrderError } = await supabase
          .from('second_contract_orders')
          .update({
            status: 'settled',
            result: finalResult,
            final_price: finalPrice,
            profit: profit,
            settled_at: new Date().toISOString()
          })
          .eq('id', order.id);

        if (updateOrderError) {
          console.error(`Error updating order ${order.id}:`, updateOrderError);
          errorCount++;
          continue;
        }

        // 查询用户当前余额
        const { data: existingBalance } = await supabase
          .from('user_balances')
          .select('*')
          .eq('user_id', order.user_id)
          .eq('currency', 'USDT')
          .eq('account_type', 'spot')
          .single();

        if (existingBalance) {
          let newAvailable: number;
          let newFrozen: number;
          
          // 如果赢了,释放本金+收益
          if (finalResult === 'win') {
            const totalReturn = Number(order.amount) + profit;
            newAvailable = Number(existingBalance.available) + totalReturn;
            newFrozen = Number(existingBalance.frozen) - Number(order.amount);
          } else {
            // 如果输了,只释放冻结的金额(已经扣除)
            newFrozen = Number(existingBalance.frozen) - Number(order.amount);
            newAvailable = Number(existingBalance.available);
          }

          // 更新余额
          const { error: balanceError } = await supabase
            .from('user_balances')
            .update({
              available: newAvailable,
              frozen: newFrozen,
              updated_at: new Date().toISOString()
            })
            .eq('id', existingBalance.id);

          if (balanceError) {
            console.error(`Error updating balance for order ${order.id}:`, balanceError);
            errorCount++;
            continue;
          }
        } else {
          // 创建新余额(这种情况应该不会发生,因为下单时已创建)
          if (finalResult === 'win') {
            const totalReturn = Number(order.amount) + profit;
            const { error: balanceError } = await supabase
              .from('user_balances')
              .insert({
                user_id: order.user_id,
                currency: 'USDT',
                available: totalReturn,
                frozen: 0,
                account_type: 'spot'
              });

            if (balanceError) {
              console.error(`Error creating balance for order ${order.id}:`, balanceError);
              errorCount++;
              continue;
            }
          }
        }

        // 记录审计日志
        await supabase.from('audit_logs').insert({
          user_id: order.user_id,
          action: 'contract_auto_settled',
          resource_type: 'second_contract_order',
          resource_id: order.id,
          details: {
            symbol: order.symbol,
            direction: order.direction,
            amount: order.amount,
            entry_price: order.entry_price,
            final_price: finalPrice,
            result: finalResult,
            profit: profit,
            admin_result: order.admin_result,
            global_control_used: globalControlMode !== 'none' ? globalControlMode : null
          }
        });

        settledCount++;
        console.log(`Settled order ${order.id}: ${finalResult}, profit: ${profit}`);
      } catch (orderError) {
        console.error(`Error processing order ${order.id}:`, orderError);
        errorCount++;
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Settled ${settledCount} orders, ${errorCount} errors`,
        settledCount,
        errorCount
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in settlement function:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error?.message || '结算失败'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});